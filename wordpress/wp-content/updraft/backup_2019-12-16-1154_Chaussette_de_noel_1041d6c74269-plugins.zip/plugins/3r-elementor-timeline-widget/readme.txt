=== Elementor Timeline Widget ===
Contributors: rafiul17
Donate link: https://www.paypal.me/HHaq
Tags: Elementor, addons, timeline, widget, roadmap
Requires at least: 3.0.1
Tested up to: 5.3
Stable tag: 5.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
 
Add Elementor Timeline Widget with easy way.  


== Description ==
Adds Timeline Addons/Widgets that are specifically designed to be used in conjunction with the Elementor Page Builder.


Video tutorial link:

[youtube https://youtu.be/51t-8qmhP6o]

== Screenshot ==

== Installation ==
Please check on video tutorial.

[youtube https://youtu.be/51t-8qmhP6o]

== Changelog ==
= 1.2 =
*Release Date - 16th January, 2019*
Add Image Option, Image Style tab, Box style Option, Content update without refresh.

= 1.1 =
Add Style Tab, Title Color, Typography, Timeline Color. 

= 1.0 =
*Release Date - 21th October, 2018*



* Initial Release